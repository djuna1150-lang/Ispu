package com.hollowmodz.ispu

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.drawable.GradientDrawable
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var value = 390
    private var numberLabel: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { showBubble(); return START_STICKY }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams = WindowManager.LayoutParams(
        width, height,
        if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 220 }

    private fun rounded(color: Int, stroke: Int = Color.RED): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = 24f; setStroke(2, stroke)
    }
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(8, 8, 8, 8)
    }
    private fun button(text: String, action: () -> Unit): TextView = label(text, 15f, Color.WHITE, true).apply {
        background = rounded(Color.BLACK); setPadding(8, 12, 8, 12); setOnClickListener { action() }
    }

    private fun showBubble() {
        if (bubble != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = label("IS", 18f, Color.WHITE, true).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(235,0,0)); setStroke(3, Color.WHITE) }
            elevation = 8f
        }
        val p = params(58, 58)
        b.setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if(abs(dx)>5 || abs(dy)>5) moved=true; p.x=ox+dx; p.y=oy+dy; wm.updateViewLayout(b,p); return true }
                    MotionEvent.ACTION_UP -> { if(!moved) { if(panel==null) showPanel() else hidePanel() }; return true }
                }; return false
            }
        })
        bubble=b; wm.addView(b,p)
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(5,5,5,5); background=rounded(Color.BLACK) }
        box.addView(label("MODDED BY HOLLOW MODZ", 13f, Color.RED, true))
        box.addView(label("Subscribe YouTube | Hollow Modz22", 8f, Color.WHITE))
        box.addView(label("WEAPON > ISPU EDIT", 15f, Color.WHITE, true).apply { background=rounded(Color.RED,Color.RED) })
        box.addView(button("ISPU +") { value=(value+1).coerceAtMost(500); updateNumber() })
        box.addView(button("ISPU -") { value=(value-1).coerceAtLeast(0); updateNumber() })
        box.addView(button("RESET ISPU") { value=390; updateNumber() })
        numberLabel=label("Demo ISPU: $value", 12f, Color.LTGRAY)
        box.addView(numberLabel)
        val bottom=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        bottom.addView(button("HIDE") { hidePanel() }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(button("CLOSE") { stopSelf() }, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(bottom)
        panel=box
        wm.addView(box, params(250, WindowManager.LayoutParams.WRAP_CONTENT).apply { x=90; y=220 })
    }
    private fun updateNumber() { numberLabel?.text = "Demo ISPU: $value" }
    private fun hidePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null }
    override fun onDestroy() { hidePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble=null; super.onDestroy() }
}
